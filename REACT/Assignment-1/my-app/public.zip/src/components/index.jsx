import React from "react"

const List=()=>{
    return(
    <>
        <div>
            <h1>Mobile Operation System</h1>
            <ul>
                <li>Android</li>
                <li>Blackberry</li>
                <li>iPhone</li>
                <li>Windows Phone</li>
            </ul>
            
        </div>
        <div>
            <h1>Mobile Manufactures</h1>
            <ul>
                <li>Samsung</li>
                <li>HTC</li>
                <li>Microphone</li>
                <li>Apple</li>
            </ul>
            
        </div>
   </>
      
    )
}
export  default List;