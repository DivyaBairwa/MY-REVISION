import List from "./components/index";
import "./App.css";

function App() {
  return (
    <>
      <List />
    </>
  );
}

export default App;
